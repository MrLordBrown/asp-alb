module.exports = {
  "globDirectory": "public/",
  "globPatterns": [
    "**/*.{png,mp3,ico,html,js,webmanifest}"
  ],
    "swDest": "public/sw.js",
    "maximumFileSizeToCacheInBytes": 18018240
};
